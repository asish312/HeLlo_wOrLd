﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MyApplication
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        public string strQueue = "";
        string vConnction = ConfigurationSettings.AppSettings["vConnStr"];
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                BindUserTable();
            }

        }
        protected void BindUserTable()
        {
          
            SqlCommand sqlcmd = new SqlCommand("Sp_UserMasterDetails",vConnction);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(sqlcmd);

            DataSet dt = new DataSet();
            da.Fill(dt);
          
            DataSet dsQueue = dt;

            if (dsQueue != null)
            {
                if (dsQueue.Tables[0] != null)
                {
                    if (dsQueue.Tables[0].Rows.Count > 0)
                    {
                        for (int loanCnt = 0; loanCnt < dsQueue.Tables[0].Rows.Count; loanCnt++)
                        {

                            strQueue += "<tr>";
                            strQueue += "<td>" + (loanCnt + 1) + "</td>";

                            strQueue += "<td>" + dsQueue.Tables[0].Rows[loanCnt]["LoginId"].ToString().Trim() + "</td>";
                            strQueue += "<td>" + dsQueue.Tables[0].Rows[loanCnt]["FirstName"].ToString().Trim() + " " + dsQueue.Tables[0].Rows[loanCnt]["LastName"].ToString().Trim() + "</td>";
                            strQueue += "<td>" + dsQueue.Tables[0].Rows[loanCnt]["Role"].ToString().Trim() + "</td>";

                            strQueue += "</tr>";
                        }
                    }
                }
            }
        }
    }
}


   